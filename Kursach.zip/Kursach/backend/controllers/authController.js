const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const pool = require('../models/db');

exports.register = async (req, res) => {
  try {
    // Регистрация пользователя
  } catch (error) {
    console.error('Error during registration:', error);
    res.status(500).send('Error during registration');
  }
};

exports.login = async (req, res) => {
  try {
    // Авторизация пользователя
  } catch (error) {
    console.error('Error during login:', error);
    res.status(500).send('Error during login');
  }
};
