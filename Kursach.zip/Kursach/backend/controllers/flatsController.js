const pool = require('../models/db');

exports.createFlat = async (req, res) => {
  try {
    // Создание квартиры
  } catch (error) {
    console.error('Error adding flat:', error);
    res.status(500).send('Error adding flat');
  }
};

exports.getFlats = async (req, res) => {
  try {
    // Получение списка квартир
  } catch (error) {
    console.error('Error getting flats:', error);
    res.status(500).send('Error getting flats');
  }
};
