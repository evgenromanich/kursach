const express = require('express');
const { Client } = require('pg');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const bcrypt = require('bcrypt');
const app = express();
const cors = require('cors');
const multer = require('multer');
const PORT = process.env.PORT || 8080;

app.use(cors());

// Подключение к базе данных PostgreSQL
const client = new Client({
  user: 'postgres',
  host: '127.0.0.1',
  database: 'postgres',
  password: 'password',
  port: 5432,
});

client.connect()
  .then(() => {
    console.log('Connected to PostgreSQL database');
  })
  .catch(err => {
    console.error('Error connecting to PostgreSQL database', err);
  });

// Middleware
app.use(express.json());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/uploads', express.static('uploads'));

// Конфигурация почтового отправителя
const transporter = nodemailer.createTransport({
  host: 'smtp.mail.ru',
  port: '465',
  secure: true,
  auth: {
    user: 'yevgeniy.rakitin.05@mail.ru',
    pass: 'dnmGb2C9T1mHzmZ0aefj'
  }
}, {
  from: 'test app <yevgeniy.rakitin.05@mail.ru>'
});

// Используем один секретный ключ для подписи и верификации токенов
const secretKey = 'your_secret_key_here';

// Функция для генерации JWT токена
const generateAccessToken = (user_id, role_id) => {
  return jwt.sign({ user_id, role_id }, secretKey, { expiresIn: '1h' });
};

// Middleware для аутентификации токена
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Получаем токен из заголовка Authorization
  if (!token) return res.status(401).json({ error: 'Unauthorized' });

  // Верификация токена
  jwt.verify(token, secretKey, (err, decoded) => {
    if (err) {
      console.error('Error verifying token:', err);
      return res.status(403).json({ error: 'Forbidden' });
    }
    req.user = decoded;
    console.log('Decoded token:', decoded);
    next();
  });
};

// Регистрация нового пользователя
app.post('/register', async (req, res) => {
  const { full_name, email, password, phone_number } = req.body;

  try {
    // Проверка наличия пользователя с таким email в базе данных
    const existingUser = await client.query('SELECT * FROM users WHERE email = $1', [email]);
    if (existingUser.rows.length > 0) {
      return res.status(400).json({ error: 'User already exists' });
    }

    // Хеширование пароля
    const hashedPassword = await bcrypt.hash(password, 10);

    // Добавление нового пользователя в базу данных с хешированным паролем
    const newUser = await client.query('INSERT INTO users (full_name, email, password, phone_number, role_id) VALUES ($1, $2, $3, $4, 1) RETURNING *', [full_name, email, hashedPassword, phone_number]);

    // Генерация JWT токена для подтверждения регистрации
    const token = generateAccessToken(newUser.rows[0].id, newUser.rows[0].role_id);

    // Отправка письма для подтверждения регистрации
    transporter.sendMail({
      to: email,
      subject: 'Confirm Registration',
      html: `
        <p>Please click the following link to confirm your registration:</p>
        <a href="http://localhost:8080/confirm/${token}">Confirm Registration</a>
      `
    });

    return res.status(201).json({ message: 'User registered successfully. Confirmation email sent.' });
  } catch (error) {
    console.error('Error registering user:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// Подтверждение регистрации
app.get('/confirm/:token', async (req, res) => {
  const token = req.params.token;
  try {
    // Верификация JWT токена для подтверждения регистрации
    const verifyToken = jwt.verify(token, secretKey);
    const { user_id } = verifyToken;
    
    // Поиск пользователя по user_id
    const user = await client.query('SELECT * FROM users WHERE id = $1', [user_id]);
    if (!user.rows[0]) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Пометка пользователя как подтвержденного
    await client.query('UPDATE users SET confirmed = true WHERE id = $1', [user_id]);

    // Генерация нового JWT токена для авторизации пользователя
    const authToken = generateAccessToken(user_id, user.rows[0].role_id);

    return res.status(200).json({ message: 'Account confirmed successfully', token: authToken });
  } catch (error) {
    console.error(error);
    return res.status(400).json({ error: 'Invalid or expired token' });
  }
});

// Авторизация пользователя
app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    // Поиск пользователя по email
    const user = await client.query('SELECT * FROM users WHERE email = $1', [email]);
    if (user.rows.length === 0) {
      return res.status(401).json({ error: 'Неверный email или пароль' });
    }

    // Сравнение введенного пароля с хешированным паролем в базе данных
    const passwordMatch = await bcrypt.compare(password, user.rows[0].password);
    if (!passwordMatch) {
      return res.status(401).json({ error: 'Неверный email или пароль' });
    }

    // Генерация JWT токена для аутентификации пользователя
    const authToken = generateAccessToken(user.rows[0].id, user.rows[0].role_id);

    // Включение role_id в ответ
    res.json({ token: authToken, role_id: user.rows[0].role_id });
  } catch (error) {
    console.error('Ошибка при входе:', error);
    res.status(500).json({ error: 'Внутренняя ошибка сервера' });
  }
});

// Получение списка заявок пользователя
app.get('/user/applications', authenticateToken, async (req, res) => {
  try {
    const user_id = req.user.user_id;
    const applications = await client.query('SELECT * FROM applications WHERE buyer_id = $1', [user_id]);
    res.status(200).json({ applications: applications.rows });
  } catch (error) {
    console.error('Error fetching user applications:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Получение списка всех заявок на квартиры (для администратора)
app.get('/admin/applications', authenticateToken, async (req, res) => {
  try {
    // Проверка роли пользователя
    const { role_id } = req.user;
    if (role_id !== 2) { // Проверка роли администратора
      return res.status(403).json({ error: 'Forbidden. Only administrators can view all applications.' });
    }

    // Получаем все заявки из базы данных
    const applications = await client.query('SELECT * FROM applications');
    res.status(200).json({ applications: applications.rows });
  } catch (error) {
    console.error('Error fetching applications:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Добавление новой заявки на квартиру
app.post('/applications', authenticateToken, async (req, res) => {
  const { flat_id, status } = req.body;

  try {
    // Извлечение user_id из декодированного токена
    const user_id = req.user.user_id;

    // Проверка наличия квартиры с указанным flat_id
    const flat = await client.query('SELECT * FROM flats WHERE id = $1', [flat_id]);
    if (flat.rows.length === 0) {
      return res.status(404).json({ error: 'Flat not found' });
    }

    // Вставка новой заявки в базу данных с указанием buyer_id
    const newApplication = await client.query('INSERT INTO applications (flat_id, buyer_id, status) VALUES ($1, $2, $3) RETURNING *', [flat_id, user_id, status]);

    // Отправка ответа об успешном создании заявки
    res.status(201).json({ message: 'Application created successfully', application: newApplication.rows[0] });
  } catch (error) {
    console.error('Error creating application:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Удаление заявки на квартиру пользователя
app.delete('/applications/:id', authenticateToken, async (req, res) => {
  const applicationId = req.params.id;

  try {
    // Извлечение user_id из декодированного токена
    const user_id = req.user.user_id;

    // Проверка наличия заявки с указанным applicationId и соответствия ее buyer_id текущему пользователю
    const application = await client.query('SELECT * FROM applications WHERE id = $1 AND buyer_id = $2', [applicationId, user_id]);
    if (application.rows.length === 0) {
      return res.status(404).json({ error: 'Application not found or unauthorized' });
    }

    // Удаление заявки из базы данных
    await client.query('DELETE FROM applications WHERE id = $1', [applicationId]);

    // Отправка ответа об успешном удалении заявки
    res.status(200).json({ message: 'Application deleted successfully' });
  } catch (error) {
    console.error('Error deleting user application:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Обновление состояния заявки администратором
app.put('/admin/applications/:id', authenticateToken, async (req, res) => {
  try {
    // Проверка роли пользователя
    const { role_id } = req.user;
    if (role_id !== 2) { // Проверка роли администратора
      return res.status(403).json({ error: 'Forbidden. Only administrators can update application status.' });
    }

    // Извлечение идентификатора заявки и нового состояния из запроса
    const { id } = req.params;
    const { status } = req.body;

    // Обновление состояния заявки в базе данных
    await client.query('UPDATE applications SET status = $1 WHERE id = $2', [status, id]);

    res.status(200).json({ message: 'Application status updated successfully' });
  } catch (error) {
    console.error('Error updating application status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Конфигурация multer для загрузки файлов
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/')
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname) // Добавляем дату в имя файла для уникальности
  }
});

const fileFilter = (req, file, cb) => {
  if (file.mimetype === 'image/png') { // Проверяем MIME-тип файла
    cb(null, true);
  } else {
    cb(new Error('Only PNG images are allowed'), false);
  }
};

const upload = multer({ storage: storage, fileFilter: fileFilter });

// Добавление новой квартиры
app.post('/flats', authenticateToken, upload.single('image_url'), async (req, res) => {
  const { total_area, living_area, cost_per_sqm, kitchen_area, total_cost, floor, num_rooms, status } = req.body;
  const image_url = req.file.path; // Получаем путь к загруженному изображению

  try {
    // Проверка роли пользователя
    const { role_id } = req.user;
    if (role_id !== 2) { // Проверка роли администратора
      return res.status(403).json({ error: 'Forbidden. Only administrators can add flats.' });
    }

    // Добавление новой квартиры в базу данных
    const newFlat = await client.query('INSERT INTO flats (total_area, living_area, cost_per_sqm, kitchen_area, total_cost, floor, num_rooms, status, image_url) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *', [total_area, living_area, cost_per_sqm, kitchen_area, total_cost, floor, num_rooms, status, image_url]);
    
    // Отправка ответа об успешном создании квартиры
    res.status(201).json({ message: 'Flat added successfully', flat: newFlat.rows[0] });
  } catch (error) {
    console.error('Error adding flat:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Удаление квартиры по ID
app.delete('/flats/:id', authenticateToken, async (req, res) => {
  const flatId = req.params.id;

  try {
    // Извлечение role_id из декодированного токена
    const { role_id } = req.user;

    // Проверка роли пользователя
    if (role_id !== 2) { // Проверка роли администратора
      return res.status(403).json({ error: 'Forbidden. Only administrators can delete flats.' });
    }

    // Удаление квартиры из базы данных
    const result = await client.query('DELETE FROM flats WHERE id = $1', [flatId]);

    // Проверка, была ли удалена квартира
    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Flat not found' });
    }

    // Отправка ответа об успешном удалении квартиры
    res.status(200).json({ message: 'Flat deleted successfully' });
  } catch (error) {
    console.error('Error deleting flat:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Обновление информации о квартире по ID
app.put('/flats/:id', authenticateToken, async (req, res) => {
  const flatId = req.params.id;
  const newData = req.body;

  try {
    // Проверка роли пользователя
    const { role_id } = req.user;
    if (role_id !== 2) { // Проверка роли администратора
      return res.status(403).json({ error: 'Forbidden. Only administrators can edit flats.' });
    }

    // Обновление информации о квартире в базе данных
    await client.query(`
      UPDATE flats 
      SET total_area = $1, living_area = $2, cost_per_sqm = $3, kitchen_area = $4, total_cost = $5, floor = $6, num_rooms = $7, status = $8 
      WHERE id = $9
    `, [newData.total_area, newData.living_area, newData.cost_per_sqm, newData.kitchen_area, newData.total_cost, newData.floor, newData.num_rooms, newData.status, flatId]);

    res.status(200).json({ message: 'Flat information updated successfully' });
  } catch (error) {
    console.error('Error updating flat information:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Получение списка всех квартир
app.get('/flats', async (req, res) => {
  try {
    const flats = await client.query('SELECT * FROM flats');
    res.status(200).json({ flats: flats.rows });
  } catch (error) {
    console.error('Error fetching flats:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Получение списка квартир для текущего пользователя
app.get('/user/flats', authenticateToken, async (req, res) => {
  try {
    const user_id = req.user.user_id;
    const flats = await client.query('SELECT * FROM flats WHERE owner_id = $1', [user_id]);
    res.status(200).json({ flats: flats.rows });
  } catch (error) {
    console.error('Error fetching user flats:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Получение информации о пользователе
app.get('/user', authenticateToken, async (req, res) => {
  try {
    const user = await client.query('SELECT * FROM users WHERE id = $1', [req.user.user_id]);
    if (user.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.status(200).json({ user: user.rows[0] });
  } catch (error) {
    console.error('Error fetching user data:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Слушаем порт
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
