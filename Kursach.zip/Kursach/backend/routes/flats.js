const express = require('express');
const router = express.Router();
const flatsController = require('../controllers/flatsController');

router.post('/', flatsController.createFlat);
router.get('/', flatsController.getFlats);

module.exports = router;
