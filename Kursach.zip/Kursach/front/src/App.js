import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import RegisterForm from './components/RegisterForm';
import LoginForm from './components/LoginForm';
import UserOffice from './components/UserOffice';// Импортируем компонент UserOffice
import AdminPage from './components/AdminPage';
import AuthPage from './components/AuthPage';
import Home from './components/Home';
import AboutUs from './components/AboutUs';
import Contact from './components/Contact';
import Calculator from './components/Calculator';
import Header from './components/bloks/Header';
import Footer from './components/bloks/Footer';

const App = () => {
  return (
    <Router>
      <div>
        <Header />
        <Routes>
          <Route path="/register" element={<RegisterForm />} />
          <Route path="/login" element={<LoginForm />} />
          <Route path="/useroffice" element={<UserOffice />} />
          <Route path="/admin" element={<AdminPage />} />
          <Route path="/authpage" element={<AuthPage />} /> 
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<AboutUs />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/calculator" element={<Calculator />} />
        </Routes>
				<Footer />
      </div>
    </Router>
  );
};

export default App;
