import React, { useState } from 'react';
import axios from 'axios';

const RegisterForm = () => {
  const [formData, setFormData] = useState({
    full_name: '',
    email: '',
    password: '',
    phone_number: ''
  });

  const handleChange = e => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8080/register', formData);
      console.log(response.data);
      // Добавьте обработку успешного ответа здесь, например, перенаправление пользователя на другую страницу
    } catch (error) {
      console.error(error.response.data);
      // Добавьте обработку ошибок здесь, например, отображение сообщения об ошибке пользователю
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input type="text" name="full_name" value={formData.full_name} onChange={handleChange} placeholder="Name"/>
      <input type="email" name="email" value={formData.email} onChange={handleChange} placeholder="Email"/>
      <input type="password" name="password" value={formData.password} onChange={handleChange} placeholder="Password"/>
      <input type="tel" name="phone_number" value={formData.phone_number} onChange={handleChange} placeholder="Phone"/>
      <button type="submit">Зарегистрироваться</button>
    </form>
  );
};

export default RegisterForm;
