import React, { useEffect, useState } from 'react';
import axios from 'axios';
import AddFlatForm from './bloks/AddFlatForm';
import FlatCard from './bloks/FlatCard';
import ModalAdmin from './bloks/ModalAdmin';
import './css/AdminPage.css';

const AdminPage = () => {
  const [userData, setUserData] = useState(null);
  const [flats, setFlats] = useState([]);
  const [applications, setApplications] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [flatsPerPage] = useState(5);
  const [applicationsPerPage] = useState(5);
  const [searchArea, setSearchArea] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searchApplicationId, setSearchApplicationId] = useState('');
  const [searchApplicationResults, setSearchApplicationResults] = useState([]);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [flatToDelete, setFlatToDelete] = useState(null);
  const [tokenExpired, setTokenExpired] = useState(false);

  const fetchUserData = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:8080/user', {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      setUserData(response.data.user);
    } catch (error) {
      console.error('Error fetching user data:', error);
    }
  };

  const fetchFlats = async () => {
    try {
      const response = await axios.get('http://localhost:8080/flats');
      setFlats(response.data.flats);
    } catch (error) {
      console.error('Error fetching flats:', error);
    }
  };

  const fetchApplications = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:8080/admin/applications', {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      setApplications(response.data.applications);
    } catch (error) {
      console.error('Error fetching applications:', error);
      if (error.response && error.response.status === 401) {
        setTokenExpired(true);
      }
    }
  };

  useEffect(() => {
    fetchUserData();
    fetchFlats();
    fetchApplications();

    const intervalId = setInterval(fetchFlats, 5000);

    return () => clearInterval(intervalId);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    window.location.href = '/authpage';
  };

  const paginateApplications = (pageNumber) => setCurrentPage(pageNumber);

  const handleSearchChange = (event) => setSearchArea(event.target.value);

  const handleSearchSubmit = (event) => {
    event.preventDefault();
    const results = flats.filter(flat => flat.total_area.toString().includes(searchArea));
    setSearchResults(results);
    setCurrentPage(1);
  };

  const handleApplicationSearchIdChange = (event) => setSearchApplicationId(event.target.value);

  const handleApplicationSearchIdSubmit = (event) => {
    event.preventDefault();
    const results = applications.filter(application => application.id.toString().includes(searchApplicationId));
    setSearchApplicationResults(results);
  };

  const handleChangeStatus = async (applicationId, newStatus) => {
    try {
      const token = localStorage.getItem('token');
      await axios.put(`http://localhost:8080/admin/applications/${applicationId}`, { status: newStatus }, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      const updatedApplications = applications.map(application =>
        application.id === applicationId ? { ...application, status: newStatus } : application
      );
      setApplications(updatedApplications);
    } catch (error) {
      console.error('Error updating application status:', error);
    }
  };

  const confirmDelete = async () => {
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:8080/flats/${flatToDelete.id}`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      const updatedFlats = flats.filter(flat => flat.id !== flatToDelete.id);
      setFlats(updatedFlats);
      setShowConfirmation(false);
    } catch (error) {
      console.error('Error deleting flat:', error);
    }
  };

  const cancelDelete = () => {
    setFlatToDelete(null);
    setShowConfirmation(false);
  };

  const indexOfLastFlat = currentPage * flatsPerPage;
  const indexOfFirstFlat = indexOfLastFlat - flatsPerPage;
  const currentFlats = searchResults.length > 0 ? searchResults.slice(indexOfFirstFlat, indexOfLastFlat) : flats.slice(indexOfFirstFlat, indexOfLastFlat);

  const indexOfLastApplication = currentPage * applicationsPerPage;
  const indexOfFirstApplication = indexOfLastApplication - applicationsPerPage;
  const currentApplications = searchApplicationResults.length > 0 ? searchApplicationResults.slice(indexOfFirstApplication, indexOfLastApplication) : applications.slice(indexOfFirstApplication, indexOfLastApplication);

  return (
    <div className="Adminpanel">
      {tokenExpired ? (
        <div>
          <h2>Ваша сессия истекла</h2>
          <button onClick={handleLogout}>Войти заново</button>
        </div>
      ) : (
        <>
          <div className="z10">Админ панель</div>
					<button className="exit_button" onClick={handleLogout}>Выход</button>
          {userData && (
            <div className="admin_inf">
              <h3 className="z">Данные пользователя</h3>
              <p className="inf">Логин: {userData.full_name}</p>
              <p className="inf">Email: {userData.email}</p>
              <p className="inf">Номер телефона: {userData.phone_number}</p>
            </div>
          )}
          <AddFlatForm />
          <div className="exit">Поиск по площади квартир</div>
          <form className="search" onSubmit={handleSearchSubmit}>
            <input className='search_flat' type="number" placeholder="Введите площадь" value={searchArea} onChange={handleSearchChange} />
            <button className="search_button" type="submit">Поиск</button>
          </form>
          {searchResults.length > 0 && (
            <div className="search-results">
              {searchResults.map(result => (
                <FlatCard key={result.id} flat={result} />
              ))}
            </div>
          )}
          <div className="exit">Список квартир</div>
          <div className="flat-list">
            {currentFlats.map(flat => (
              <div key={flat.id}>
                <FlatCard flat={flat} />
              </div>
            ))}
          </div>
          <div>
            {flats.length > flatsPerPage && (
              <ul className="pagination">
                {Array.from({ length: Math.ceil(flats.length / flatsPerPage) }, (_, i) => (
                  <li key={i} className={currentPage === i + 1 ? 'active' : ''}>
                    <button className="search_button" onClick={() => paginateApplications(i + 1)}>{i + 1}</button>
                  </li>
                ))}
              </ul>
            )}
          </div>
          <ModalAdmin
            isOpen={showConfirmation}
            onClose={cancelDelete}
            onDelete={confirmDelete}
          />
          <div className="exit">Поиск заявок по ID</div>
          <form className="search" onSubmit={handleApplicationSearchIdSubmit}>
            <input className='search_flat' type="text" placeholder="Введите ID заявки" value={searchApplicationId} onChange={handleApplicationSearchIdChange} />
            <button className="search_button">Поиск</button>
          </form>
          <div className="exit">Заявки</div>
          <div className="applications-list">
            {currentApplications.map(application => (
              <div className="applications-card" key={application.id}>
                <h3 className="inf_applications">ID квартиры: {application.flat_id}</h3>
                <div className="inf_applications">ID пользователя: {application.buyer_id}</div>
                <div className="inf_applications">Статус заявки: {application.status}</div>
                <form onSubmit={(e) => {
                  e.preventDefault();
                  handleChangeStatus(application.id, e.target.status.value);
                }}>
                  <select className='auth' name="status">
                    <option value="approved">Одобрено</option>
                    <option value="rejected">Не одобрено</option>
                  </select>
                  <button type="submit">Изменить статус</button>
                </form>
              </div>
            ))}
          </div>
          {applications.length > applicationsPerPage && (
            <ul className="pagination">
              {Array.from({ length: Math.ceil(applications.length / applicationsPerPage) }, (_, i) => (
                <li key={i} className={currentPage === i + 1 ? 'active' : ''}>
                  <button className="search_button" onClick={() => paginateApplications(i + 1)}>{i + 1}</button>
                </li>
              ))}
            </ul>
          )}
        </>
      )}
    </div>
  );
};

export default AdminPage;
