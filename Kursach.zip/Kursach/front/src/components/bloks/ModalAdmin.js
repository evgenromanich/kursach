import React from 'react';

const ModalAdmin = ({ isOpen, onClose, onDelete }) => {
  if (!isOpen) {
    return null;
  }

  return (
    <div className="modal">
      <div className="modal-content">
        <h2>Вы уверены, что хотите удалить эту Квартиру?</h2>
        <div className="modal-buttons">
          <button onClick={onDelete}>Удалить</button>
          <button onClick={onClose}>Отмена</button>
        </div>
      </div>
    </div>
  );
};

export default ModalAdmin;
