// AddFlatForm.js
import React, { useState } from 'react';
import axios from 'axios';
import '../css/AuthPage.css';
const AddFlatForm = () => {
  const [formData, setFormData] = useState({
    total_area: '',
    living_area: '',
    cost_per_sqm: '',
    kitchen_area: '',
    total_cost: '',
    floor: '',
    num_rooms: '',
    status: '',
    image_url: null
  });

  const handleChange = e => {
    if (e.target.name === 'image_url') {
      setFormData({ ...formData, image_url: e.target.files[0] });
    } else {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    }
  };

  const handleSubmit = async e => {
    e.preventDefault();
    try {
      const postData = new FormData();
      for (let key in formData) {
        postData.append(key, formData[key]);
      }
      const token = localStorage.getItem('token'); // Получение токена из локального хранилища
      const response = await axios.post('http://localhost:8080/flats', postData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'Authorization': `Bearer ${token}` // Включение токена в заголовок запроса
        }
      });
      console.log(response.data);
      // Добавьте обработку успешного ответа здесь, например, обновление списка квартир на странице
    } catch (error) {
      console.error(error.response.data);
      // Добавьте обработку ошибок здесь, например, отображение сообщения об ошибке пользователю
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input className='auth' type="text" name="total_area" value={formData.total_area} onChange={handleChange} placeholder="Площадь квартиры"/>
      <input className='auth' type="text" name="living_area" value={formData.living_area} onChange={handleChange} placeholder="Жилая площадь"/>
      <input className='auth' type="text" name="cost_per_sqm" value={formData.cost_per_sqm} onChange={handleChange} placeholder="Стоимость за 1м²"/>
      <input className='auth' type="text" name="kitchen_area" value={formData.kitchen_area} onChange={handleChange} placeholder="Площадь кухни"/>
      <input className='auth' type="text" name="total_cost" value={formData.total_cost} onChange={handleChange} placeholder="Полная стоимость"/>
      <input className='auth' type="text" name="floor" value={formData.floor} onChange={handleChange} placeholder="Этаж"/>
      <input className='auth' type="text" name="num_rooms" value={formData.num_rooms} onChange={handleChange} placeholder="Количество комнат"/>
      <input className='auth' type="text" name="status" value={formData.status} onChange={handleChange} placeholder="Статус квартриы"/>
      <input className='auth' type="file" name="image_url" onChange={handleChange} accept="image/*" />
      <button type="submit">Добавить квартиру</button>
    </form>
  );
};

export default AddFlatForm;
