import React from 'react';

const Modal = ({ isOpen, onClose, onDelete }) => {
  if (!isOpen) {
    return null;
  }

  return (
    <div className="modal">
      <div className="modal-content">
        <h2>Вы уверены, что хотите удалить эту заявку?</h2>
        <div className="modal-buttons">
          <button onClick={onDelete}>Удалить</button>
          <button onClick={onClose}>Отмена</button>
        </div>
      </div>
    </div>
  );
};

export default Modal;
