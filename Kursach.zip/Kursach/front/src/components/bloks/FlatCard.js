import React, { useState } from 'react';
import axios from 'axios';
import Modal from './Modal';
import '../css/AdminPage.css';

const FlatCard = ({ flat }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    total_area: flat.total_area,
    living_area: flat.living_area,
    cost_per_sqm: flat.cost_per_sqm,
    kitchen_area: flat.kitchen_area,
    total_cost: flat.total_cost,
    floor: flat.floor,
    num_rooms: flat.num_rooms,
    status: flat.status
  });
  const [showConfirmation, setShowConfirmation] = useState(false);

  const imageUrl = flat.image_url ? `http://localhost:8080/${flat.image_url}` : '';

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const toggleEdit = () => {
    setIsEditing(!isEditing);
  };

  const openConfirmation = () => {
    setShowConfirmation(true);
  };

  const closeConfirmation = () => {
    setShowConfirmation(false);
  };

  const handleDelete = () => {
    openConfirmation();
  };

  const handleConfirmDelete = async () => {
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:8080/flats/${flat.id}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      // Добавьте обработку успешного удаления здесь, например, обновление списка квартир на странице
      // Закрываем модальное окно подтверждения
      closeConfirmation();
    } catch (error) {
      console.error(error.response.data);
      // Добавьте обработку ошибок здесь, например, отображение сообщения об ошибке пользователю
    }
  };

  const handleSave = async () => {
    try {
      const token = localStorage.getItem('token');
      await axios.put(`http://localhost:8080/flats/${flat.id}`, formData, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      // Добавьте обработку успешного сохранения здесь, например, обновление списка квартир на странице
      // После сохранения изменений переключаемся из режима редактирования
      toggleEdit();
    } catch (error) {
      console.error(error.response.data);
      // Добавьте обработку ошибок здесь, например, отображение сообщения об ошибке пользователю
    }
  };

  return (
    <div className="flat-card">
      <img className="flat-img" src={imageUrl} alt="Flat" />
      <div className="flat-details">
				<div className="flat-inf">
					<p className="inf_flat">Площадь квартиры: {formData.total_area} м²</p>
        	<p className="inf_flat">Жил площадь: {formData.living_area} м²</p>
        	<p className="inf_flat">Стоимость 1м²: {formData.cost_per_sqm}</p>
        	<p className="inf_flat">Кухни: {formData.kitchen_area} м²</p>
      	  <p className="inf_flat">Стоимость: {formData.total_cost}</p>
      	  <p className="inf_flat">Этаж: {formData.floor}</p>
      	  <p className="inf_flat">Комнаты: {formData.num_rooms}</p>
      	  <p className="inf_flat">Статус: {formData.status}</p>
				</div>
        {isEditing && (
          <>
            <input type="text" name="total_area" value={formData.total_area} onChange={handleChange} />
            <input type="text" name="living_area" value={formData.living_area} onChange={handleChange} />
            <input type="text" name="cost_per_sqm" value={formData.cost_per_sqm} onChange={handleChange} />
            <input type="text" name="kitchen_area" value={formData.kitchen_area} onChange={handleChange} />
            <input type="text" name="total_cost" value={formData.total_cost} onChange={handleChange} />
            <input type="text" name="floor" value={formData.floor} onChange={handleChange} />
            <input type="text" name="num_rooms" value={formData.num_rooms} onChange={handleChange} />
            <input type="text" name="status" value={formData.status} onChange={handleChange} />
            <button className='work_button' onClick={handleSave}>Сохранить</button> {/* Добавляем кнопку "Сохранить" */}
          </>
        )}
				<div className='blok_butons'>
					<button className='work_button' onClick={toggleEdit}>{isEditing ? 'Отменить' : 'Изменить'}</button>
        	<button className='work_button' onClick={handleDelete}>Удалить</button>
				</div>
      </div>
      {showConfirmation && (
        <Modal
          isOpen={showConfirmation}
          onClose={closeConfirmation}
          onDelete={handleConfirmDelete}
        />
      )}
    </div>
  );
};

export default FlatCard;
