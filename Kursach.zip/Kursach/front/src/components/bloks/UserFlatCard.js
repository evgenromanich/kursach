// UserFlatCard.js
import React from 'react';
import axios from 'axios';

const UserFlatCard = ({ flat }) => {
  const imageUrl = flat.image_url ? `http://localhost:8080/${flat.image_url}` : '';

  const handleApply = async () => {
    try {
      const token = localStorage.getItem('token'); // Получение токена из локального хранилища
      await axios.post('http://localhost:8080/applications', {
        flat_id: flat.id,
        status: 'pending' // Устанавливаем статус заявки
      }, {
        headers: {
          Authorization: `Bearer ${token}` // Включение токена в заголовок запроса
        }
      });
      alert('Application submitted successfully!');
    } catch (error) {
      console.error('Error submitting application:', error);
      alert('Failed to submit application. Please try again later.');
    }
  };

  return (
    <div className="flat-card">
      <img src={imageUrl} alt="Flat" />
      <div className="flat-details">
        <p>Площадь квартиры: {flat.total_area}</p>
        <p>Жилая площадь: {flat.living_area}</p>
        <p>Стоимость за 1м²: {flat.cost_per_sqm}</p>
        <p>Площадь кухни: {flat.kitchen_area}</p>
        <p>Полная стоимость: {flat.total_cost}</p>
        <p>Этаж: {flat.floor}</p>
        <p>Количество комнат: {flat.num_rooms}</p>
        <p>Статус квартриы: {flat.status}</p>
        <button onClick={handleApply}>Apply</button> {/* Кнопка "Оставить заявку" */}
      </div>
    </div>
  );
};

export default UserFlatCard;
