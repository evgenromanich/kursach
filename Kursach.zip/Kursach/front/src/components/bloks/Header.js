import React from 'react';
import '../css/Home.css';
import { Link } from 'react-router-dom';
function Header() {
  return (
    <header>
      <div className="container">
        <nav className="nav">
          <div className="nav-logo"><img className="logo" src="/img/image 2.svg" alt="logo" /></div>
          <div className="nav-menu" id="navMenu">
						<div className="y">
							<Link to="/" className="link_img"><img className="i q" src="/img/image 3.svg" alt="Логотип моего сайта"/></Link>
    					<Link to="/" className="link">Москва</Link>
						</div>
						<div className="y">
							<Link to="/str_6/index.html" className="link_img"><img className="i w" src="/img/image 4.svg" alt="Логотип моего сайта"/></Link>
    					<Link to="/str_6/index.html" className="link">Купить</Link>
						</div>
						<div className="y">
							<Link to="/contact" className="link_img"><img className="i e" src="/img/image 5.svg" alt="Логотип моего сайта"/></Link>
    					<Link to="/contact" className="link">Контакты</Link>
						</div>
						<div className="y">
							<Link to="/calculator" className="link_img"><img className="i r" src="/img/image 6.svg" alt="Логотип моего сайта"/></Link>
    					<Link to="/calculator" className="link">Ипотека</Link>
						</div>
						<div className="y">
							<Link to="/about" className="link_img"><img className="i p" src="/img/image 7.svg" alt="Логотип моего сайта"/></Link>
    					<Link to="/about" className="link">О нас</Link>
						</div>
						<div className="y">
							<Link to="/authpage" className="link_img"><img className="i y" src="/img/image 8.svg" alt="Логотип моего сайта"/></Link>
    					<Link to="/authpage" className="link">Регистрация</Link>
						</div>
          </div>
        </nav>
      </div>
      <div className="garden"><img className="garden_1" src="/img/garden.png" alt="garden" /></div>
    </header>
  );
}

export default Header;
