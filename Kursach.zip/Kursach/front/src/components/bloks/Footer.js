import React from 'react';
import '../css/Home.css';
import { Link } from 'react-router-dom';
function Footer() {
  return (
    <footer>
      <nav className="nav_2">
        <div className="nav-logo_2"><img className="logo" src="/img/image 2.svg" alt="logo" /></div>
        <div className="nav-menu_2" id="navMenu_2">
					<Link to="/" className="link">Москва</Link>
					<Link to="/str_6/index.html" className="link">Купить</Link>
					<Link to="/contact" className="link">Контакты</Link>
					<Link to="/calculator" className="link">Ипотека</Link>
					<Link to="/about" className="link">О нас</Link>
					<Link to="/authpage" className="link">Регистрация</Link>
        </div>
      </nav>
      <nav className="nav_3">
        <div className="nav-menu_3" id="navMenu_3">
          <a href="#" className="link_img_2"><img className="soc" src="/img/Soc_1.svg" alt="social" /></a>
          <a href="#" className="link_img_2"><img className="soc" src="/img/Soc_2.svg" alt="social" /></a>
          <a href="#" className="link_img_2"><img className="soc" src="/img/Soc_3.svg" alt="social" /></a>
          <a href="#" className="link_img_2"><img className="soc" src="/img/Soc_4.svg" alt="social" /></a>
        </div>
        <div className="blok_right">
          <div className="z4">Наши контакты</div>
          <div className="kontact">
            <div className="nomer">+7 999 999 99 99</div>
            <div className="line"></div>
            <div className="nomer">StroyDom@gmail.com</div>
          </div>
        </div>
      </nav>
    </footer>
  );
}

export default Footer;
