import React, { useState } from 'react';
import axios from 'axios';
import './css/AuthPage.css';

const AuthPage = () => {
  const [registerFormData, setRegisterFormData] = useState({
    full_name: '',
    email: '',
    password: '',
    phone_number: ''
  });

  const [loginFormData, setLoginFormData] = useState({
    email: '',
    password: ''
  });

  const [isSignUpActive, setIsSignUpActive] = useState(false);

  const handleRegisterChange = e => {
    setRegisterFormData({ ...registerFormData, [e.target.name]: e.target.value });
  };

  const handleLoginChange = e => {
    setLoginFormData({ ...loginFormData, [e.target.name]: e.target.value });
  };

  const handleRegisterSubmit = async e => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8080/register', registerFormData);
      console.log(response.data);
    } catch (error) {
      console.error(error.response.data);
    }
  };

  const handleLoginSubmit = async e => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8080/login', loginFormData);
      const token = response.data.token;
      const role = response.data.role_id;

      localStorage.setItem('token', token);
      localStorage.setItem('username', response.data.full_name);

      if (role === 2) {
        window.location.href = '/admin';
      } else {
        window.location.href = '/useroffice';
      }
    } catch (error) {
      console.error(error.response.data);
    }
  };

  const toggleSignUp = () => {
    setIsSignUpActive(true);
  };

  const toggleSignIn = () => {
    setIsSignUpActive(false);
  };

  return (
    <div className={`container_1 ${isSignUpActive ? 'right-panel-active' : ''}`}>
      <div className={`container`}>
        <div className={`form-container sign-up-container ${isSignUpActive ? 'overlay-left-active' : ''}`}>
          <form onSubmit={handleRegisterSubmit}>
            <h2>Регистрация</h2>
            <input className="auth" type="text" name="full_name" value={registerFormData.full_name} onChange={handleRegisterChange} placeholder="Name"/>
            <input className="auth" type="email" name="email" value={registerFormData.email} onChange={handleRegisterChange} placeholder="Email"/>
            <input className="auth" type="password" name="password" value={registerFormData.password} onChange={handleRegisterChange} placeholder="Password"/>
            <input className="auth" type="tel" name="phone_number" value={registerFormData.phone_number} onChange={handleRegisterChange} placeholder="Phone"/>
            <button type="submit">Зарегистрироваться</button>
          </form>
        </div>
        <div className={`form-container sign-in-container ${isSignUpActive ? 'overlay-right-active' : ''}`}>
          <form onSubmit={handleLoginSubmit}>
            <h2>Вход</h2>
            <input className="auth" type="email" name="email" value={loginFormData.email} onChange={handleLoginChange} placeholder="Email" />
            <input className="auth" type="password" name="password" value={loginFormData.password} onChange={handleLoginChange} placeholder="Password" />
            <button type="submit">Войти</button>
          </form>
        </div>
        <div className="overlay-container">
          <div className="overlay">
            <div className="overlay-panel overlay-left">
              <img className="log_1" src="/img/image 13.png" alt="Sign In Logo"/>
              <p>Чтобы оставаться на связи с нами, пожалуйста, войдите, используя свои личные данные.</p>
              <button className="ghost" onClick={toggleSignIn}>Войти</button>
            </div>
            <div className="overlay-panel overlay-right">
              <img className="log" src="/img/image 2.svg" alt="Sign Up Logo"/>
              <p>Введите свои личные данные и начните путешествие вместе с нами</p>
              <button className="ghost" onClick={toggleSignUp}>Зарегистрироваться</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;
