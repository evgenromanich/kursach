import React from 'react';
import './css/AboutUs.css';
import { useState } from 'react';

function AboutUs() {
	const [slideIndex, setSlideIndex] = useState(0);

  const slides = [
    "/img/1.svg",
    "/img/2.svg",
    "/img/3.svg",
    "/img/4.svg",
    "/img/5.svg"
  ];

  function plusSlides(n) {
    const newIndex = (slideIndex + n + slides.length) % slides.length;
    setSlideIndex(newIndex);
  }

  function currentSlide(index) {
    setSlideIndex(index);
  }

  return (
    <div className="blok_inf1">
      <div className="inf1">
        <div className="z1">О нас</div>
        <div className="text1">
          С момента создания нашей строительной компании, мы создаём новое и комфортабельное жильё, которое отвечает всем 
          стандартам качества и люди могут приобрести жильё в наших новостройках по очень доступной цене. 
          Дворы наших зданий соответствуют новым стандартам урбанистики таким как: безопасные детские площадки, 
          дворовая территория без автомобильных парковок, подземные автопарковки, современные системы отвода воды 
          и озеленение дворовой территории.
        </div>
      </div>
      <div className="inf_left">
			<div className="slider">
              {slides.map((slide, index) => (
                <div key={index} className={slideIndex === index ? 'slide' : 'slide hidden'}>
                  <img src={slide} className="slider_img" alt={`Slide ${index + 1}`} />
                </div>
              ))}
              <a href="#!" className="prev" onClick={() => plusSlides(-1)}>&#10094;</a>
              <a href="#!" className="next" onClick={() => plusSlides(1)}>&#10095;</a>
            </div>
            <div className="dot_1">
              {slides.map((_, index) => (
                <span key={index} className={slideIndex === index ? 'dot active' : 'dot'} onClick={() => currentSlide(index)}></span>
              ))}
            </div>
      </div>
    </div>
  );
}

export default AboutUs;
