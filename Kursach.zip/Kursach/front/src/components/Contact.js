import React from 'react';
import './css/Contact.css'; // импортируем ваши стили

function Contact() {
  return (
    <div className="block_inf5">
      <div className="block_left">
        <div className="zcon">Наши контакты</div>
        <p className="inf_con">Наша компания работает ежедневно с 9:00 до 22:00</p>
        <p className="inf_con">В выходные и праздничные дни мы работаем с 9:30 до 20:30</p>
        <div className="zcon">Наш адрес:</div>
        <p className="inf_con">г. Владимир ул. Университетская д. 4 к. 321</p>
        <div className="zcon">Наши контакты:</div>
        <div className="nomer_t">+7 999 999 99 99</div>
        <div className="nomer_t">+7 495 321 22 11</div>
        <div className="zcon">Наша почта:</div>
        <div className="nomer_t">StroyDom@gmail.com</div>
        <div className="zcon">Наши контакты в соцсетях</div>
        <div className="nav_4">
          <div className="nav-menu_4" id="navMenu_4">
            <a href="#" className="link_img_3"><img className="soc_1" src="/img/Soc1.svg"/></a>						
            <a href="#" className="link_img_3"><img className="soc_1" src="/img/Soc2.svg"/></a>
            <a href="#" className="link_img_3"><img className="soc_1" src="/img/Soc3.svg"/></a>
            <a href="#" className="link_img_3"><img className="soc_1" src="/img/Soc4.svg"/></a>
          </div>
        </div>
      </div>
      <div className="block_right">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2223.1521698308857!2d40.3662703!3d56.1371813!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x414c7be2a83aabb9%3A0x48999fe07988221f!2z0KPQvdC40LLQtdGA0YHQuNGC0LXRgtGB0LrQsNGPINGD0LsuLCA0LCDQktC70LDQtNC40LzQuNGALCDQktC70LDQtNC40LzQuNGA0YHQutCw0Y8g0L7QsdC7LiwgNjAwMDIx!5e0!3m2!1sru!2sru!4v1698957059409!5m2!1sru!2sru" width="500vw" height="400vh" style={{ border: '0' }} allowFullScreen="" loading="lazy" referrerPolicy="no-referrer-when-downgrade" title="Google Maps"></iframe>
			</div>
		</div>
  );
}

export default Contact;
