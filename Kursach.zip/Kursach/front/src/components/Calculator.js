import React from 'react';
import { useState } from 'react';
import './css/Calculator.css'; // импортируем ваши стили



function Calculator() {
  const [objectPrice, setObjectPrice] = useState(3500000);
  const [firstPayment, setFirstPayment] = useState(0);
  const [years, setYears] = useState(20);
  const [bankProgram, setBankProgram] = useState(3.5); // Устанавливаем значение по умолчанию

  // Функция для расчета ежемесячного платежа
  const calculateMonthlyPayment = () => {
    const principal = objectPrice - firstPayment;
    const monthlyInterest = bankProgram / 100 / 12;
    const numberOfPayments = years * 12;
    const x = Math.pow(1 + monthlyInterest, numberOfPayments);
    const monthlyPayment = (principal * x * monthlyInterest) / (x - 1);
    return monthlyPayment.toFixed(2);
  };

  // Обработчики изменений в полях ввода
  const handleObjectPriceChange = (event) => {
    setObjectPrice(parseInt(event.target.value));
  };

  const handleFirstPaymentChange = (event) => {
    setFirstPayment(parseInt(event.target.value));
  };

  const handleYearsChange = (event) => {
    setYears(parseInt(event.target.value));
  };

  const handleBankProgramChange = (event) => {
    setBankProgram(parseFloat(event.target.value));
  };

  return (
    <div>
      <div className="x3">
        <div className="z3">Доступные ипотечные программы</div>
      </div>
      <div className="mort">
				<div className="gos">
					<div className="kart">
						<div className="kart_1">
							<div className="logo_1"><img className="log_1" src="/img/image 13.svg" alt="10 мин. пешком до станции метро Некрасовская"/></div>
							<div className="text_0">
								<div className="text_1">От застройщика</div>
								<div className="text_1_1">Выгодный платёж и сниженная ставка по ипотеке.</div>
							</div>
						</div>
						<div className="kart_2">
							<div className="bot">
								<div className="text_2">От 23 512 ₽  / мес.</div>
								<div className="knopka">
									<div className="k_1">
										<div className="proc">От 3,5%</div>
										<div className="elips">
											<div className="t"></div>
											<div className="l"></div>
											<span className="tooltiptext"><div className="tip">Ставка на ипотеку от 3,5%
												Выгодный платёж и сниженная ставка по ипотеке. Стоимость квартиры 
												может быть увеличена. Финальный расчёт предоставит застройщик.</div>
											</span>
										</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div className="gos">
						<div className="kart">
							<div className="kart_1">
								<div className="logo_1"><img className="log_1" src="/img/image 14.svg" alt="10 мин. пешком до станции метро Некрасовская"/></div>
								<div className="text_0">
									<div className="text_1">Семейная</div>
									<div className="text_1_1">Для семей с детьми </div>
								</div>
							</div>
							<div className="kart_2">
								<div className="bot">
									<div className="text_2">От 27 321 ₽  / мес.</div>
									<div className="knopka">
										<div className="k_1">
											<div className="proc">От 4,7% </div>
											<div className="elips">
												<div className="t"></div>
												<div className="l"></div>
												<span className="tooltiptext"><div className="tip">Ставка на ипотеку от 4,7%
													Выгодный платёж и сниженная ставка по ипотеке для с семей с ребёнком. Стоимость квартиры 
													может быть увеличена. Финальный расчёт предоставит застройщик.</div>
												</span>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div className="gos">
						<div className="kart">
							<div className="kart_1">
								<div className="logo_1"><img className="log_1" src="/img/image 15.svg" alt="10 мин. пешком до станции метро Некрасовская"/></div>
								<div className="text_0">
									<div className="text_1">Господдержка</div>
									<div className="text_1_1">Без требований к семейному положению</div>
								</div>
							</div>
							<div className="kart_2">
								<div className="bot">
									<div className="text_2">От 33 777 ₽  / мес.</div>
									<div className="knopka">
										<div className="k_1">
											<div className="proc">От 7,7% </div>
											<div className="elips">
												<div className="t"></div>
												<div className="l"></div>
												<span className="tooltiptext"><div className="tip">Ставка на ипотеку от 7,7%
													Ипотека с пониженной ставкой в сравнении со ставкой центробанка. Стоимость квартиры 
													может быть увеличена. Финальный расчёт предоставит застройщик.</div>
												</span>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div className="gos">
						<div className="kart">
							<div className="kart_1">
								<div className="logo_1"><img className="log_1" src="/img/image 16.svg" alt="10 мин. пешком до станции метро Некрасовская"/></div>
								<div className="text_0">
									<div className="text_1">Базовая</div>
									<div className="text_1_1">Универсальная ипотека до 100 млн </div>
								</div>
							</div>
							<div className="kart_2">
								<div className="bot">
									<div className="text_2">От 56 125 ₽  / мес.</div>
									<div className="knopka">
										<div className="k_1">
											<div className="proc">От 13,5% </div>
											<div className="elips">
												<div className="t"></div>
												<div className="l"></div>
												<span className="tooltiptext"><div className="tip">Ставка на ипотеку от 13,5%
													Ставка по ипотеке поставленная центральным банком, может менять процентную ставку. Стоимость квартиры 
													может быть увеличена. Финальный расчёт предоставит застройщик.</div>
												</span>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div className="gos">
						<div className="kart">
							<div className="kart_1">
								<div className="logo_1"><img className="log_1" src="/img/image 17.svg" alt="10 мин. пешком до станции метро Некрасовская"/></div>
								<div className="text_0">
									<div className="text_1">Ипотека для IT</div>
									<div className="text_1_1">Ипотека для специалистов IT- компаний</div>
								</div>
							</div>
							<div className="kart_2">
								<div className="bot">
									<div className="text_2">От 23 512 ₽  / мес.</div>
									<div className="knopka">
										<div className="k_1">
											<div className="proc">От 4,3% </div>
											<div className="elips">
												<div className="t"></div>
												<div className="l"></div>
												<span className="tooltiptext"><div className="tip">Ставка на ипотеку от 4,3%
													Выгодный платёж и сниженная ставка по ипотеке для IT-шников, которые работуют в окридетованой компании. Стоимость квартиры 
													может быть увеличена. Финальный расчёт предоставит застройщик.</div>
												</span>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
      <div className="x4">
        <div className="log"><img className="calculator" src="/img/image 18.svg" alt="Калькулятор" /></div>
        <div className="z5">Рассчитайте условия</div>
      </div>

			<section id="mortgage-calculator-section">
				<div className="container_calculator">
					<div className="row mortgage-calculator">
						<div className="block_inf_calculator">
							<div className="block_1_right_calculator">
								<div className="form-group">
									<label for="object-price">Стоимость недвижимости</label>
									<div className="range-output">
										<input
          type="number"
          id="object-price"
          value={objectPrice}
          onChange={handleObjectPriceChange}
        />
										<input type="hidden" id="object-price-hidden"/>
									</div>
									<input type="range" list="object-price-tickmarks" min="4000000" max="15300000" value="3500000" className="form-control-range" id="object-price"/>
									<datalist id="first-payment-tickmarks">
										<option value="4000000" label="4 млн. ₽"/>
										<option value="15300000" label="15,3 млн. ₽"/>
									</datalist>
								</div>
								<div className="form-group">
									<label for="first-payment">Первоначальный взнос</label>
									<div className="range-output">
									<input
          type="number"
          id="first-payment"
          value={firstPayment}
          onChange={handleFirstPaymentChange}
        />
                		<input type="hidden" id="first-payment-hidden"/>
									</div>
									<input type="range" list="tickmarks" min="300000" max="5000000" class="form-control-range" id="first-payment"/>
									<datalist id="tickmarks years-tickmarks">
							  		<option value="300000" label="300 тыс."/>
										<option value="5000000" label="5 млн."/>
									</datalist>
								</div>
								<div className="form-group">
									<label for="years">Срок кредита</label>
									<div className="range-output">
									<input
          type="number"
          id="years"
          value={years}
          onChange={handleYearsChange}
        />
									</div>
									<input type="range" list="years-tickmarks" min="1" max="30" value="20" class="form-control-range" id="years"/>
									<datalist id="tickmarks years-tickmarks">
							  		<option value="1" label="1 год"/>
							  		<option value="30" label="30 лет"/>
									</datalist>
								</div>
							</div>
							<div className="block_2_left">
						<div className="form-group">
							<div className="z6" for="percent">Ипотечные программы</div>
							<div className="stroka" id="percent">
							<select id="bank-select" onChange={handleBankProgramChange} value={bankProgram}>
          <option value="3.5">От застройщика</option>
          <option value="4.7">Семейная</option>
          <option value="7.7">Господдержка</option>
          <option value="13.5">Базовая</option>
          <option value="4.3">Ипотека для IT</option>
        </select>
								<div className="bank-percent">
									<input className="text-input-percent" id="bank-percent-span" value="6.5"/>%
								</div>
							</div>
						</div>
						<div className="block_inf_down">
							<div className="block_1">
								<div className="mc-item">
									<p>Сумма кредита</p>
									<p className="mc-item-number"><span id="credit-summ">2 500 000,00</span> ₽</p>
								</div>
								<div className="mc-item">
									<p>Ежемесячный платеж {calculateMonthlyPayment()} ₽</p>
									<p className="mc-item-number"><span id="month-pay">18 639,33</span> ₽</p>
								</div>
							</div>
							<div className="block_2">
								<div className="mc-item">
									<p>Платёж по нашей ставке</p>
									<p className="mc-item-number"><span id="month-pay-with-us">17 910,78</span> ₽</p>
								</div>
								<div className="mc-item mc-item-safe">
									<p>Сэкономьте с нами до</p>
									<p className="mc-item-number"><span id="your-safe">174 852,85</span> ₽ <a href="https://kluch.me/2020/05/25/%d0%b8%d0%bf%d0%be%d1%82%d0%b5%d0%ba%d0%b0-%d1%87%d0%b5%d1%80%d0%b5%d0%b7-%d0%b0%d0%b3%d0%b5%d0%bd%d1%82%d1%81%d1%82%d0%b2%d0%be-%d0%bd%d0%b5%d0%b4%d0%b2%d0%b8%d0%b6%d0%b8%d0%bc%d0%be%d1%81%d1%82/" target="_blank" class="question" title="Как можно сэкономить на ипотеке с Ключом?"><span><i class="fa fa-question-circle" aria-hidden="true"></i></span></a></p>
								</div>
							</div>
						</div>
					</div>
						</div>
					</div>
				</div>
			</section>
    </div>
  );
}

export default Calculator;
