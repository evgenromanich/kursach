import React, { useState } from 'react';
import axios from 'axios';

const LoginForm = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  const handleChange = e => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8080/login', formData);
      const token = response.data.token;
      const role = response.data.role_id;

      localStorage.setItem('token', token);
      localStorage.setItem('username', response.data.full_name);

      // Если пользователь является администратором
      if (role === 2) {
        // Выполните дополнительные действия для администратора, например, перенаправление на страницу администратора
        window.location.href = '/admin';
      } else {
        // Выполните действия для обычного пользователя, например, перенаправление на домашнюю страницу
        window.location.href = '/useroffice';
      }
    } catch (error) {
      console.error(error.response.data);
      // Обработка ошибки авторизации, например, отображение сообщения об ошибке пользователю
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input type="email" name="email" value={formData.email} onChange={handleChange} placeholder="Email" />
      <input type="password" name="password" value={formData.password} onChange={handleChange} placeholder="Password" />
      <button type="submit">Войти</button>
    </form>
  );
};

export default LoginForm;
