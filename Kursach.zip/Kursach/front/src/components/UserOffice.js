import React, { useState, useEffect } from 'react';
import axios from 'axios';
import UserFlatCard from './bloks/UserFlatCard'; // Импорт компонента UserFlatCard
import Modal from './bloks/Modal';
const UserOffice = () => {
  const [flats, setFlats] = useState([]);
  const [userApplications, setUserApplications] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [flatsPerPage] = useState(5);
  const [selectedApplicationId, setSelectedApplicationId] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    const fetchFlats = async () => {
      try {
        const response = await axios.get('http://localhost:8080/flats');
        setFlats(response.data.flats);
      } catch (error) {
        console.error('Error fetching flats:', error);
      }
    };

    const fetchUserApplications = async () => {
      try {
        const token = localStorage.getItem('token');
        if (!token) {
          throw new Error('Token not found');
        }
    
        const response = await axios.get('http://localhost:8080/user/applications', {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });
    
        setUserApplications(response.data.applications);
      } catch (error) {
        console.error('Error fetching user applications:', error);
      }
    };

    fetchFlats();
    fetchUserApplications();
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    window.location.href = '/authpage';
  };

  const deleteUserApplication = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        throw new Error('Token not found');
      }
  
      await axios.delete(`http://localhost:8080/applications/${selectedApplicationId}`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
  
      const updatedApplications = userApplications.filter(application => application.id !== selectedApplicationId);
      setUserApplications(updatedApplications);
      setIsModalOpen(false); // Закрываем модальное окно после удаления заявки
    } catch (error) {
      console.error('Error deleting user application:', error);
    }
  };

  // Функция для открытия модального окна удаления заявки
  const openModal = (applicationId) => {
    setSelectedApplicationId(applicationId);
    setIsModalOpen(true);
  };

  // Получение индексов первой и последней карточки на текущей странице
  const indexOfLastFlat = currentPage * flatsPerPage;
  const indexOfFirstFlat = indexOfLastFlat - flatsPerPage;
  const currentFlats = flats.slice(indexOfFirstFlat, indexOfLastFlat);

  // Функция для изменения текущей страницы
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  return (
    <div>
      <h1>User Profile</h1>
      <button onClick={handleLogout}>Выход</button>
      <h2>All Flats</h2>
      {currentFlats.map(flat => (
        <UserFlatCard key={flat.id} flat={flat} />
      ))}
      {/* Элементы управления для пагинации */}
      <div>
        {flats.length > flatsPerPage && (
          <ul className="pagination">
            {Array.from({ length: Math.ceil(flats.length / flatsPerPage) }, (_, i) => (
              <li key={i} className={currentPage === i + 1 ? 'active' : ''}>
                <button onClick={() => paginate(i + 1)}>{i + 1}</button>
              </li>
            ))}
          </ul>
        )}
      </div>
      <h2>My Applications</h2>
      {userApplications.map(application => (
        <div key={application.id}>
          <p>Status: {application.status}</p>
          <button onClick={() => openModal(application.id)}>Delete Application</button>
          {/* Добавьте другие данные заявки, если необходимо */}
        </div>
      ))}
      {/* Модальное окно для подтверждения удаления заявки */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onDelete={deleteUserApplication} />
    </div>
  );
};

export default UserOffice;
