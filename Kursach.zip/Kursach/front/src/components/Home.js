import React from 'react';
import { useState } from 'react';
//import Header from './Header';
//import Footer from './Footer';
import './css/Home.css'; // импортируйте стили

function Website() {
  const [slideIndex, setSlideIndex] = useState(0);

  const slides = [
    "/img/1_1.svg",
    "/img/1_2.svg",
    "/img/1_3.svg",
    "/img/1_4.svg",
    "/img/1_5.svg"
  ];

  function plusSlides(n) {
    const newIndex = (slideIndex + n + slides.length) % slides.length;
    setSlideIndex(newIndex);
  }

  function currentSlide(index) {
    setSlideIndex(index);
  }

  return (
		
    <div>
      
      {/* Вставьте сюда остальную часть вашего HTML-кода */}
      {/* Примерно так: */}
      <div className="blok_inf">
        <div className="inf_right">
          <div className="z1">Микрорайон с достойным уровнем комфорта</div>
          <div className="z2">
					<div className="slider">
              {slides.map((slide, index) => (
                <div key={index} className={slideIndex === index ? 'slide' : 'slide hidden'}>
                  <img src={slide} className="slider_img" alt={`Slide ${index + 1}`} />
                </div>
              ))}
              <a href="#!" className="prev" onClick={() => plusSlides(-1)}>&#10094;</a>
              <a href="#!" className="next" onClick={() => plusSlides(1)}>&#10095;</a>
            </div>
            <div className="dot_1">
              {slides.map((_, index) => (
                <span key={index} className={slideIndex === index ? 'dot active' : 'dot'} onClick={() => currentSlide(index)}></span>
              ))}
            </div>
          </div>
        </div>
        <div className="inf_1">
          <div className="inf">
            <div className="blok"><img className="blok_img" src="/img/image 9.svg" alt="10 мин. пешком до станции метро Некрасовская"/>
              <div className="text">10 мин. пешком до станции метро Некрасовская</div>
            </div>
            <div className="blok"><img className="blok_img" src="/img/image 10.svg" alt="5 мин. пешком до школы и детского сада"/>
              <div className="text">5 мин. пешком до школы и детского сада</div>
            </div>
            <div className="blok"><img className="blok_img" src="/img/image 11.svg" alt="Магазин в шаговой доступности"/>
              <div className="text">Магазин в шаговой доступности</div>
            </div>
            <div className="blok"><img className="blok_img" src="/img/image 12.svg" alt="Больница в 5 мин езды на общественном транспорте"/>
              <div className="text">Больница в 5 мин езды на общественном транспорте</div>
            </div>
          </div>
        </div>
      </div>
      <div className="line_1"></div>
      <div className="x3">
        <div className="z3">Доступные ипотечные программы</div>
      </div>
      <div className="mort">
        <div className="gos">
          <div className="kart">
            <div className="kart_1">
              <div className="logo_1"><img className="log_1" src="/img/image 13.svg" alt="Ипотека от застройщика"/></div>
              <div className="text_0">
                <div className="text_1">От застройщика</div>
                <div className="text_1_1">Выгодный платёж и сниженная ставка по ипотеке.</div>
              </div>
            </div>
            <div className="kart_2">
              <div className="bot">
                <div className="text_2">От 23 512 ₽  / мес.</div>
                <div className="knopka">
                  <div className="k_1">
                    <div className="proc">От 3,5%</div>
                    <div className="elips">
                      <div className="t"></div>
                      <div className="l"></div>
                      <span className="tooltiptext"><div className="tip">Ставка на ипотеку от 3,5%
                        Выгодный платёж и сниженная ставка по ипотеке. Стоимость квартиры 
                        может быть увеличена. Финальный расчёт предоставит застройщик.</div>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
				<div className="gos">
					<div className="kart">
						<div className="kart_1">
							<div className="logo_1"><img className="log_1" src="/img/image 14.svg" alt="Ипотека для семей с детьми"/></div>
							<div className="text_0">
								<div className="text_1">Семейная</div>
								<div className="text_1_1">Для семей с детьми </div>
							</div>
						</div>
						<div className="kart_2">
							<div className="bot">
								<div className="text_2">От 27 321 ₽  / мес.</div>
								<div className="knopka">
									<div className="k_1">
										<div className="proc">От 4,7% </div>
										<div className="elips">
											<div className="t"></div>
											<div className="l"></div>
											<span className="tooltiptext"><div className="tip">Ставка на ипотеку от 4,7%
												Выгодный платёж и сниженная ставка по ипотеке для с семей с ребёнком. Стоимость квартиры 
												может быть увеличена. Финальный расчёт предоставит застройщик.</div>
											</span>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div className="gos">
					<div className="kart">
						<div className="kart_1">
							<div className="logo_1"><img className="log_1" src="/img/image 15.svg" alt="Ипотека для семей с детьми"/></div>
							<div className="text_0">
								<div className="text_1">Господдержка</div>
								<div className="text_1_1">Без требований к семейному положению</div>
							</div>
						</div>
						<div className="kart_2">
							<div className="bot">
								<div className="text_2">От 33 777 ₽  / мес.</div>
								<div className="knopka">
									<div className="k_1">
										<div className="proc">От 7,7% </div>
										<div className="elips">
											<div className="t"></div>
											<div className="l"></div>
											<span className="tooltiptext"><div className="tip">Ставка на ипотеку от 7,7%
												Ипотека с пониженной ставкой в сравнении со ставкой центробанка. Стоимость квартиры 
												может быть увеличена. Финальный расчёт предоставит застройщик.</div>
											</span>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div className="gos">
					<div className="kart">
						<div className="kart_1">
							<div className="logo_1"><img className="log_1" src="/img/image 16.svg" alt="Ипотека для семей с детьми"/></div>
							<div className="text_0">
								<div className="text_1">Базовая</div>
								<div className="text_1_1">Универсальная ипотека до 100 млн </div>
							</div>
						</div>
						<div className="kart_2">
							<div className="bot">
								<div className="text_2">От 56 125 ₽  / мес.</div>
								<div className="knopka">
									<div className="k_1">
										<div className="proc">От 13,5% </div>
										<div className="elips">
											<div className="t"></div>
											<div className="l"></div>
											<span className="tooltiptext"><div className="tip">Ставка на ипотеку от 13,5%
												Ставка по ипотеке поставленная центральным банком, может менять процентную ставку. Стоимость квартиры 
												может быть увеличена. Финальный расчёт предоставит застройщик.</div>
											</span>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div className="gos">
					<div className="kart">
						<div className="kart_1">
							<div className="logo_1"><img className="log_1" src="/img/image 17.svg" alt="Ипотека для семей с детьми"/></div>
							<div className="text_0">
								<div className="text_1">Ипотека для IT</div>
								<div className="text_1_1">Ипотека для специалистов IT- компаний</div>
							</div>
						</div>
						<div className="kart_2">
							<div className="bot">
								<div className="text_2">От 23 512 ₽  / мес.</div>
								<div className="knopka">
									<div className="k_1">
										<div className="proc">От 4,3% </div>
										<div className="elips">
											<div className="t"></div>
											<div className="l"></div>
											<span className="tooltiptext"><div className="tip">Ставка на ипотеку от 4,3%
												Выгодный платёж и сниженная ставка по ипотеке для IT-шников, которые работуют в окридетованой компании. Стоимость квартиры 
												может быть увеличена. Финальный расчёт предоставит застройщик.</div>
											</span>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
      </div>

    </div>//гплгпо
  );
}

export default Website;
